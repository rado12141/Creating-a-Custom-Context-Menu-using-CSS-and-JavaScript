/** Slecting Custom Context Menu Element */
const CustomcontextMenu = document.getElementById('custom-contextmenu')


/** Opening Custom Context Menu */
window.addEventListener('contextmenu', (e) => {
    e.preventDefault()
    //Adding Class to Context Menu Element to trigger show
    if(!CustomcontextMenu.classList.contains('show'))
        CustomcontextMenu.classList.add('show');
    setTimeout(()=>{
        // Re-positioning the Context Menu Element According to cursor position and left/right
        if((e.clientY +  CustomcontextMenu.clientHeight) < window.innerHeight){
            CustomcontextMenu.style.top = e.clientY + `px`;
            CustomcontextMenu.querySelectorAll('.custom-contextmenu-sub').forEach(el=>{
                if(el.classList.contains('up'))
                    el.classList.remove('up');
            })
        }else{
            CustomcontextMenu.style.top = (e.clientY - CustomcontextMenu.clientHeight) + `px`;
            CustomcontextMenu.querySelectorAll('.custom-contextmenu-sub').forEach(el=>{
                if(!el.classList.contains('up'))
                    el.classList.add('up');
            })
        }
        if((e.clientX +  CustomcontextMenu.clientWidth) < window.innerWidth){
            CustomcontextMenu.style.left = e.clientX + `px`
            CustomcontextMenu.querySelectorAll('.custom-contextmenu-sub').forEach(el=>{
                if(el.classList.contains('left'))
                    el.classList.remove('left');
            })
        }else{
            CustomcontextMenu.style.left = (e.clientX - CustomcontextMenu.clientWidth) + `px`;
            CustomcontextMenu.querySelectorAll('.custom-contextmenu-sub').forEach(el=>{
                if(!el.classList.contains('left'))
                    el.classList.add('left');
            })
        }
    }, 0)

    /** Event Listenter for submenu is hovered */
    CustomcontextMenu.querySelectorAll('.custom-contextmenu-link.multi-lvl').forEach((el)=>{
        el.addEventListener('mouseenter', function(){
            var submenu = el.parentElement.querySelector('.custom-contextmenu-sub')
            // Open Submenu
            if(submenu !== undefined && !submenu.classList.contains('show'))
                    submenu.classList.add('show')

            //Hiding the submenu
            el.parentElement.addEventListener('mouseleave', e =>{
                if(submenu !== undefined && submenu.classList.contains('show'))
                    submenu.classList.remove('show')
            })
        })
    })
})

/** Event Listener for Hiding the Custom Context Menu */
window.addEventListener('click', e => {
    var _target = e.target

    // Check if the clicked target is not a child of the context menu
    if((CustomcontextMenu).contains(_target) === true)
      return false;
    
    /** Hiding the Custom Context Menu */
    if(CustomcontextMenu.classList.contains('show'))
    CustomcontextMenu.classList.remove('show')
})